/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#12100e',        // primary background
        ink2: '#1a1714',       // raised surface
        ink3: '#211d19',       // card / hover surface
        line: '#2b2620',       // hairline borders
        gold: {
          DEFAULT: '#c5a059',
          light: '#d9bc84',
          dim: '#8f7644',
          muted: '#a68a56',
        },
        bone: '#ece7dd',       // primary text on dark
        smoke: '#a39c8f',      // secondary text
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        body: ['"Jost"', '"Helvetica Neue"', 'Arial', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      letterSpacing: {
        widest2: '0.28em',
      },
      backgroundImage: {
        'gold-fade': 'linear-gradient(90deg, transparent, #c5a059, transparent)',
      },
      boxShadow: {
        gold: '0 0 0 1px rgba(197,160,89,0.35)',
        lift: '0 20px 60px -20px rgba(0,0,0,0.6)',
      },
      transitionTimingFunction: {
        luxe: 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
    },
  },
  plugins: [],
}
