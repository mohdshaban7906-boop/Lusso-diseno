import { useEffect, useState } from 'react'
import { Package, ShoppingCart, IndianRupee, Clock } from 'lucide-react'
import { subscribeToOrders } from '../firebase/orders'
import { useProducts } from '../hooks/useProducts'
import { formatINR } from '../utils/format'

export default function AdminDashboard() {
  const { products } = useProducts()
  const [orders, setOrders] = useState([])

  useEffect(() => {
    const unsub = subscribeToOrders(setOrders, () => {})
    return () => unsub()
  }, [])

  const totalRevenue = orders.reduce((sum, o) => sum + (o.total || 0), 0)
  const pendingOrders = orders.filter((o) => o.status === 'pending').length

  const stats = [
    { label: 'Total Orders', value: orders.length, icon: ShoppingCart },
    { label: 'Total Revenue', value: formatINR(totalRevenue), icon: IndianRupee },
    { label: 'Products Listed', value: products.length, icon: Package },
    { label: 'Pending Orders', value: pendingOrders, icon: Clock },
  ]

  return (
    <div>
      <h2 className="font-display text-2xl text-bone mb-6">Overview</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {stats.map((s) => (
          <div key={s.label} className="bg-ink2 border border-line p-6">
            <s.icon size={18} strokeWidth={1.5} className="text-gold mb-4" />
            <div className="text-2xl font-display text-bone">{s.value}</div>
            <div className="text-xs text-smoke tracking-wide mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="mt-10">
        <h3 className="font-display text-xl text-bone mb-4">Recent Orders</h3>
        <div className="border border-line divide-y divide-line">
          {orders.slice(0, 5).map((o) => (
            <div key={o.id} className="p-4 flex items-center justify-between text-sm">
              <div>
                <div className="text-bone">{o.name}</div>
                <div className="text-xs text-smoke">{o.phone}</div>
              </div>
              <div className="text-gold">{formatINR(o.total)}</div>
            </div>
          ))}
          {orders.length === 0 && (
            <p className="p-6 text-smoke text-sm text-center">No orders yet.</p>
          )}
        </div>
      </div>
    </div>
  )
}
