import { useEffect, useState } from 'react'
import { subscribeToOrders } from '../firebase/orders'
import { formatINR } from '../utils/format'

export default function AdminOrders() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState(null)

  useEffect(() => {
    const unsub = subscribeToOrders(
      (data) => {
        setOrders(data)
        setLoading(false)
      },
      () => setLoading(false)
    )
    return () => unsub()
  }, [])

  return (
    <div>
      <h2 className="font-display text-2xl text-bone mb-6">Orders</h2>

      {loading ? (
        <p className="text-smoke text-sm">Loading…</p>
      ) : orders.length === 0 ? (
        <p className="text-smoke text-sm">No orders have been placed yet.</p>
      ) : (
        <div className="border border-line divide-y divide-line">
          {orders.map((o) => (
            <div key={o.id}>
              <button
                onClick={() => setExpanded(expanded === o.id ? null : o.id)}
                className="w-full p-4 flex items-center justify-between text-left hover:bg-ink3 transition-colors"
              >
                <div>
                  <div className="text-sm text-bone">{o.name}</div>
                  <div className="text-xs text-smoke">{o.phone} · {o.email}</div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-xs px-2 py-1 border border-line text-smoke uppercase tracking-wide">
                    {o.status || 'pending'}
                  </span>
                  <span className="text-gold text-sm">{formatINR(o.total)}</span>
                </div>
              </button>

              {expanded === o.id && (
                <div className="px-4 pb-5 pt-1 bg-ink3/50">
                  <p className="text-xs text-smoke mb-3">{o.address}</p>
                  {o.notes && <p className="text-xs text-smoke mb-3 italic">Note: {o.notes}</p>}
                  <div className="space-y-1.5">
                    {(o.items || []).map((item, idx) => (
                      <div key={idx} className="flex justify-between text-xs text-bone">
                        <span>{item.title} × {item.quantity} {item.finish && `(${item.finish})`}</span>
                        <span>{formatINR(item.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
