import { useState } from 'react'
import { LayoutDashboard, Package, ShoppingCart, LogOut } from 'lucide-react'
import { useAdminAuth } from '../hooks/useAdminAuth'
import AdminLogin from './AdminLogin'
import AdminDashboard from './AdminDashboard'
import AdminProducts from './AdminProducts'
import AdminOrders from './AdminOrders'

const TABS = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { key: 'products', label: 'Products', icon: Package },
  { key: 'orders', label: 'Orders', icon: ShoppingCart },
]

export default function AdminPanel() {
  const { user, checking, login, logout } = useAdminAuth()
  const [tab, setTab] = useState('dashboard')

  if (checking) {
    return (
      <div className="min-h-screen bg-ink flex items-center justify-center">
        <div className="w-8 h-8 border border-line border-t-gold rounded-full animate-spin" />
      </div>
    )
  }

  if (!user) {
    return <AdminLogin onLogin={login} />
  }

  return (
    <div className="min-h-screen bg-ink flex">
      {/* Sidebar */}
      <aside className="w-60 shrink-0 border-r border-line hidden sm:flex flex-col">
        <div className="p-6 border-b border-line">
          <div className="font-display text-xl text-bone">LUSSO</div>
          <div className="text-[9px] tracking-widest2 text-gold mt-1">ATELIER PANEL</div>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm transition-colors ${
                tab === t.key ? 'bg-ink2 text-gold' : 'text-smoke hover:text-bone'
              }`}
            >
              <t.icon size={16} strokeWidth={1.5} />
              {t.label}
            </button>
          ))}
        </nav>
        <button
          onClick={logout}
          className="m-4 flex items-center gap-3 px-4 py-3 text-sm text-smoke hover:text-red-400 transition-colors border-t border-line pt-6"
        >
          <LogOut size={16} strokeWidth={1.5} />
          Sign Out
        </button>
      </aside>

      {/* Mobile tab bar */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-50 bg-ink2 border-t border-line flex">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex-1 flex flex-col items-center gap-1 py-3 text-[10px] ${
              tab === t.key ? 'text-gold' : 'text-smoke'
            }`}
          >
            <t.icon size={16} strokeWidth={1.5} />
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <main className="flex-1 p-6 md:p-10 pb-24 sm:pb-10 overflow-y-auto">
        {tab === 'dashboard' && <AdminDashboard />}
        {tab === 'products' && <AdminProducts />}
        {tab === 'orders' && <AdminOrders />}
      </main>
    </div>
  )
}
