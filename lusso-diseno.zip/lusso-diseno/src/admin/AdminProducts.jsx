import { useState } from 'react'
import { Plus, Pencil, Trash2, X } from 'lucide-react'
import { useProducts } from '../hooks/useProducts'
import { createProduct, updateProduct, deleteProduct } from '../firebase/products'
import { formatINR } from '../utils/format'

const emptyForm = {
  title: '',
  price: '',
  category: '',
  finish: '',
  description: '',
  image: '',
}

export default function AdminProducts() {
  const { products, loading } = useProducts()
  const [editingId, setEditingId] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  function openCreate() {
    setForm(emptyForm)
    setEditingId(null)
    setShowForm(true)
  }

  function openEdit(product) {
    setForm({
      title: product.title || '',
      price: product.price || '',
      category: product.category || '',
      finish: product.finish || '',
      description: product.description || '',
      image: product.image || '',
    })
    setEditingId(product.id)
    setShowForm(true)
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    try {
      const payload = { ...form, price: Number(form.price) || 0 }
      if (editingId) {
        await updateProduct(editingId, payload)
      } else {
        await createProduct(payload)
      }
      setShowForm(false)
      setForm(emptyForm)
      setEditingId(null)
    } catch (err) {
      console.error(err)
      alert('Failed to save product. Check Firestore rules.')
    } finally {
      setSaving(false)
    }
  }

  async function handleDelete(id) {
    if (!confirm('Delete this product permanently?')) return
    try {
      await deleteProduct(id)
    } catch (err) {
      console.error(err)
      alert('Failed to delete product. Check Firestore rules.')
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-2xl text-bone">Products</h2>
        <button
          onClick={openCreate}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-gold text-ink text-xs tracking-widest2 uppercase hover:bg-gold-light transition-colors"
        >
          <Plus size={14} strokeWidth={1.5} /> Add Product
        </button>
      </div>

      {loading ? (
        <p className="text-smoke text-sm">Loading…</p>
      ) : (
        <div className="border border-line divide-y divide-line">
          {products.map((p) => (
            <div key={p.id} className="p-4 flex items-center gap-4">
              <div className="w-14 h-14 bg-ink2 shrink-0 overflow-hidden">
                {p.image && <img src={p.image} alt={p.title} className="w-full h-full object-cover" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-bone truncate">{p.title}</div>
                <div className="text-xs text-smoke">{p.category} {p.finish && `· ${p.finish}`}</div>
              </div>
              <div className="text-gold text-sm shrink-0">{formatINR(p.price)}</div>
              <div className="flex gap-2 shrink-0">
                <button
                  onClick={() => openEdit(p)}
                  className="w-8 h-8 flex items-center justify-center text-smoke hover:text-gold border border-line"
                  aria-label="Edit"
                >
                  <Pencil size={14} strokeWidth={1.5} />
                </button>
                <button
                  onClick={() => handleDelete(p.id)}
                  className="w-8 h-8 flex items-center justify-center text-smoke hover:text-red-400 border border-line"
                  aria-label="Delete"
                >
                  <Trash2 size={14} strokeWidth={1.5} />
                </button>
              </div>
            </div>
          ))}
          {products.length === 0 && (
            <p className="p-6 text-smoke text-sm text-center">No products yet. Add your first piece.</p>
          )}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-5">
          <div className="w-full max-w-lg bg-ink2 border border-line p-7 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-xl text-bone">
                {editingId ? 'Edit Product' : 'New Product'}
              </h3>
              <button onClick={() => setShowForm(false)} className="text-smoke hover:text-gold">
                <X size={18} strokeWidth={1.5} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <Field label="Title" value={form.title} onChange={(v) => setForm((f) => ({ ...f, title: v }))} required />
              <Field label="Price (INR)" type="number" value={form.price} onChange={(v) => setForm((f) => ({ ...f, price: v }))} required />
              <Field label="Category" value={form.category} onChange={(v) => setForm((f) => ({ ...f, category: v }))} placeholder="e.g. Brass Wall Art" />
              <Field label="Finish" value={form.finish} onChange={(v) => setForm((f) => ({ ...f, finish: v }))} placeholder="e.g. Brushed Brass" />
              <Field label="Image URL" value={form.image} onChange={(v) => setForm((f) => ({ ...f, image: v }))} placeholder="https://..." />
              <label className="block">
                <span className="text-xs text-smoke tracking-wide">Description</span>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  className="w-full mt-2 bg-ink border border-line px-4 py-3 text-sm text-bone focus:border-gold outline-none transition-colors"
                />
              </label>

              <button
                type="submit"
                disabled={saving}
                className="w-full px-6 py-3.5 bg-gold text-ink text-[13px] tracking-widest2 uppercase hover:bg-gold-light transition-all disabled:opacity-60"
              >
                {saving ? 'Saving…' : editingId ? 'Save Changes' : 'Create Product'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

function Field({ label, value, onChange, type = 'text', required, placeholder }) {
  return (
    <label className="block">
      <span className="text-xs text-smoke tracking-wide">{label}{required && ' *'}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        placeholder={placeholder}
        className="w-full mt-2 bg-ink border border-line px-4 py-3 text-sm text-bone placeholder:text-smoke/50 focus:border-gold outline-none transition-colors"
      />
    </label>
  )
}
