import { useState } from 'react'
import { Lock } from 'lucide-react'

export default function AdminLogin({ onLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    setError(null)
    try {
      await onLogin(email, password)
    } catch (err) {
      setError('Invalid credentials. Check the Firebase Authentication user list.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-ink flex items-center justify-center px-5">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-full border border-gold/40 flex items-center justify-center mb-4">
            <Lock size={18} strokeWidth={1.5} className="text-gold" />
          </div>
          <h1 className="font-display text-2xl text-bone">Atelier Access</h1>
          <p className="text-xs text-smoke mt-1 tracking-wide">Lusso Diseño — Admin Panel</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="Admin email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full bg-ink2 border border-line px-4 py-3 text-sm text-bone placeholder:text-smoke/50 focus:border-gold outline-none transition-colors"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full bg-ink2 border border-line px-4 py-3 text-sm text-bone placeholder:text-smoke/50 focus:border-gold outline-none transition-colors"
          />
          {error && <p className="text-xs text-red-400">{error}</p>}
          <button
            type="submit"
            disabled={submitting}
            className="w-full px-6 py-3.5 bg-gold text-ink text-[13px] tracking-widest2 uppercase hover:bg-gold-light transition-all duration-400 ease-luxe disabled:opacity-60"
          >
            {submitting ? 'Signing in…' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  )
}
