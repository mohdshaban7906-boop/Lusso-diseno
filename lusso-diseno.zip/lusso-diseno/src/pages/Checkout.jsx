import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { CheckCircle2, Loader2 } from 'lucide-react'
import { useCart } from '../context/CartContext'
import { createOrder } from '../firebase/orders'
import { formatINR } from '../utils/format'
import { EmptyState } from '../components/UI'

const initialForm = { name: '', email: '', phone: '', address: '', city: '', pincode: '', notes: '' }

export default function Checkout() {
  const { items, subtotal, clearCart } = useCart()
  const navigate = useNavigate()

  const [form, setForm] = useState(initialForm)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)

  function handleChange(e) {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    if (items.length === 0) return

    setSubmitting(true)
    setError(null)

    try {
      const orderId = await createOrder({
        name: form.name,
        email: form.email,
        phone: form.phone,
        address: `${form.address}, ${form.city} ${form.pincode}`.trim(),
        notes: form.notes,
        items: items.map((i) => ({
          productId: i.productId,
          title: i.title,
          price: i.price,
          quantity: i.quantity,
          finish: i.finish,
        })),
        total: subtotal,
      })
      setSuccess(orderId.id)
      clearCart()
    } catch (err) {
      console.error(err)
      setError('Something went wrong placing your order. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  if (success) {
    return (
      <div className="max-w-[1400px] mx-auto px-5 md:px-10">
        <EmptyState
          title="Order placed"
          subtitle={`Thank you — our atelier will reach out within 24 hours to confirm delivery details. Reference: ${success.slice(0, 8).toUpperCase()}`}
          action={
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 px-7 py-3 border border-gold text-gold text-[13px] tracking-widest2 uppercase hover:bg-gold hover:text-ink transition-all duration-400 ease-luxe"
            >
              Continue Shopping
            </Link>
          }
        />
        <CheckCircle2 className="mx-auto -mt-4 mb-10 text-gold" size={28} strokeWidth={1.25} />
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="max-w-[1400px] mx-auto px-5 md:px-10">
        <EmptyState
          title="Your cart is empty"
          subtitle="Add pieces to your cart before checking out."
          action={
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 px-7 py-3 border border-gold text-gold text-[13px] tracking-widest2 uppercase hover:bg-gold hover:text-ink transition-all duration-400 ease-luxe"
            >
              Shop the Collection
            </Link>
          }
        />
      </div>
    )
  }

  return (
    <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-14">
      <h1 className="font-display font-light text-4xl text-bone mb-10">Checkout</h1>

      <div className="grid lg:grid-cols-[1fr_360px] gap-12">
        <form onSubmit={handleSubmit} className="space-y-7">
          <div>
            <h4 className="eyebrow mb-5">Contact</h4>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Full Name" name="name" value={form.name} onChange={handleChange} required />
              <Field label="Phone" name="phone" value={form.phone} onChange={handleChange} required type="tel" />
              <Field label="Email" name="email" value={form.email} onChange={handleChange} type="email" className="sm:col-span-2" />
            </div>
          </div>

          <div>
            <h4 className="eyebrow mb-5">Delivery Address</h4>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Street Address" name="address" value={form.address} onChange={handleChange} required className="sm:col-span-2" />
              <Field label="City" name="city" value={form.city} onChange={handleChange} required />
              <Field label="Pincode" name="pincode" value={form.pincode} onChange={handleChange} required />
            </div>
          </div>

          <div>
            <h4 className="eyebrow mb-5">Order Notes (optional)</h4>
            <textarea
              name="notes"
              value={form.notes}
              onChange={handleChange}
              rows={3}
              className="w-full bg-ink2 border border-line px-4 py-3 text-sm text-bone placeholder:text-smoke/50 focus:border-gold outline-none transition-colors"
              placeholder="Delivery instructions, gift notes, etc."
            />
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-10 py-3.5 bg-gold text-ink text-[13px] tracking-widest2 uppercase hover:bg-gold-light transition-all duration-400 ease-luxe disabled:opacity-60"
          >
            {submitting ? (
              <>
                <Loader2 size={15} className="animate-spin" /> Placing Order
              </>
            ) : (
              'Place Order'
            )}
          </button>
        </form>

        <div className="h-fit bg-ink2 border border-line p-7">
          <h4 className="eyebrow mb-5">Order Summary</h4>
          <div className="space-y-4 mb-6 max-h-72 overflow-y-auto pr-1">
            {items.map((item) => (
              <div key={item.lineId} className="flex justify-between text-sm">
                <div className="text-smoke">
                  {item.title} <span className="text-smoke/60">× {item.quantity}</span>
                </div>
                <span className="text-bone">{formatINR(item.price * item.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between text-base text-bone border-t border-line pt-5">
            <span>Total</span>
            <span className="text-gold">{formatINR(subtotal)}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

function Field({ label, name, value, onChange, required, type = 'text', className = '' }) {
  return (
    <label className={`block ${className}`}>
      <span className="text-xs text-smoke tracking-wide">{label}{required && ' *'}</span>
      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        required={required}
        className="w-full mt-2 bg-ink2 border border-line px-4 py-3 text-sm text-bone placeholder:text-smoke/50 focus:border-gold outline-none transition-colors"
      />
    </label>
  )
}
