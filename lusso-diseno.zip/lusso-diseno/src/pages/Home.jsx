import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { useProducts } from '../hooks/useProducts'
import ProductCard from '../components/ProductCard'
import { SectionHeading, Spinner } from '../components/UI'

const CATEGORIES = [
  { name: 'Brass Wall Art', image: 'https://images.unsplash.com/photo-1618220179428-22790b461013?q=80&w=800&auto=format&fit=crop' },
  { name: 'Copper Lighting', image: 'https://images.unsplash.com/photo-1540932239986-30128078f3c5?q=80&w=800&auto=format&fit=crop' },
  { name: 'Metal Sculptures', image: 'https://images.unsplash.com/photo-1611486212557-88be5ff6f941?q=80&w=800&auto=format&fit=crop' },
  { name: 'Accent Furniture', image: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?q=80&w=800&auto=format&fit=crop' },
]

export default function Home() {
  const { products, loading } = useProducts()
  const featured = products.slice(0, 8)

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-line">
        <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-16 md:py-24 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="eyebrow mb-5">Elegance in Metal</p>
            <h1 className="font-display font-light text-[42px] leading-[1.08] md:text-[64px] md:leading-[1.05] text-bone">
              Handcrafted Brass
              <br />
              &amp; Copper Décor
            </h1>
            <p className="text-smoke text-base mt-6 max-w-md leading-relaxed">
              Sculptural lighting, wall art and furniture — each piece formed
              by hand, finished to age gracefully in your home.
            </p>
            <Link
              to="/shop"
              className="inline-flex items-center gap-3 mt-9 px-8 py-3.5 border border-gold text-gold text-[13px] tracking-widest2 uppercase hover:bg-gold hover:text-ink transition-all duration-400 ease-luxe"
            >
              Shop the Collection
              <ArrowRight size={15} strokeWidth={1.5} />
            </Link>
          </div>
          <div className="relative aspect-[4/5] md:aspect-[5/6]">
            <img
              src="https://images.unsplash.com/photo-1618220179428-22790b461013?q=80&w=1200&auto=format&fit=crop"
              alt="Brass wall art sculpture, The Celestial Cascade"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-5 left-5 bg-ink/80 backdrop-blur px-4 py-2 border border-gold/30">
              <p className="text-xs text-gold tracking-wide">The Celestial Cascade</p>
            </div>
          </div>
        </div>
      </section>

      {/* Category strip */}
      <section className="max-w-[1400px] mx-auto px-5 md:px-10 py-16 md:py-20">
        <SectionHeading eyebrow="Curated Edit" title="Shop by Category" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5 mt-10">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.name}
              to={`/shop?category=${encodeURIComponent(cat.name)}`}
              className="group relative overflow-hidden aspect-[4/5] bg-ink2"
            >
              <img
                src={cat.image}
                alt={cat.name}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 ease-luxe group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-transparent" />
              <span className="absolute bottom-4 left-4 right-4 text-[12px] tracking-wide uppercase text-bone">
                {cat.name}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured products from Firestore */}
      <section className="max-w-[1400px] mx-auto px-5 md:px-10 py-16 md:py-20 border-t border-line">
        <div className="flex items-end justify-between mb-10">
          <SectionHeading eyebrow="New Arrivals" title="Featured Pieces" />
          <Link
            to="/shop"
            className="hidden sm:inline-flex items-center gap-2 text-xs tracking-widest2 uppercase text-gold hover:text-gold-light transition-colors"
          >
            View All <ArrowRight size={13} strokeWidth={1.5} />
          </Link>
        </div>

        {loading ? (
          <Spinner label="Loading collection" />
        ) : featured.length === 0 ? (
          <p className="text-smoke text-sm py-16 text-center">
            No products yet — add pieces from the admin panel to populate the shop.
          </p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-5 gap-y-10">
            {featured.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      {/* Statement band */}
      <section className="border-t border-b border-line bg-ink2">
        <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-20 text-center">
          <p className="eyebrow mb-4">Our Philosophy</p>
          <h2 className="font-display font-light text-3xl md:text-[38px] max-w-2xl mx-auto leading-snug text-bone">
            Objects made to be touched, not just admired — brass that warms with your hand, copper that deepens with time.
          </h2>
        </div>
      </section>
    </div>
  )
}
