import { useEffect, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { Minus, Plus, ShieldCheck, Truck, ArrowLeft } from 'lucide-react'
import { fetchProductById } from '../firebase/products'
import { useCart } from '../context/CartContext'
import { formatINR } from '../utils/format'
import { Spinner } from '../components/UI'

const FINISH_OPTIONS = ['Brushed Brass', 'Antique Copper', 'Matte Black']

export default function ProductDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { addItem } = useCart()

  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [quantity, setQuantity] = useState(1)
  const [finish, setFinish] = useState(FINISH_OPTIONS[0])
  const [added, setAdded] = useState(false)

  useEffect(() => {
    let active = true
    setLoading(true)
    fetchProductById(id).then((data) => {
      if (active) {
        setProduct(data)
        if (data?.finish) setFinish(data.finish)
        setLoading(false)
      }
    })
    return () => {
      active = false
    }
  }, [id])

  if (loading) return <Spinner label="Loading piece" />

  if (!product) {
    return (
      <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-24 text-center">
        <h2 className="font-display text-2xl text-bone mb-3">Piece not found</h2>
        <p className="text-smoke text-sm mb-6">This item may have been removed from the collection.</p>
        <Link to="/shop" className="text-gold text-sm tracking-wide uppercase">Back to shop</Link>
      </div>
    )
  }

  function handleAddToCart() {
    addItem(product, { finish, quantity })
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  function handleBuyNow() {
    addItem(product, { finish, quantity })
    navigate('/cart')
  }

  return (
    <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-12">
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-2 text-xs tracking-wide uppercase text-smoke hover:text-gold mb-8 transition-colors"
      >
        <ArrowLeft size={14} strokeWidth={1.5} /> Back
      </button>

      <div className="grid md:grid-cols-2 gap-12 lg:gap-20">
        <div className="aspect-[4/5] bg-ink2 overflow-hidden">
          {product.image ? (
            <img src={product.image} alt={product.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-smoke text-xs">No image</div>
          )}
        </div>

        <div className="md:pt-4">
          {product.category && <p className="eyebrow mb-3">{product.category}</p>}
          <h1 className="font-display font-light text-3xl md:text-4xl text-bone mb-4">{product.title}</h1>
          <p className="text-2xl text-gold font-body mb-6">{formatINR(product.price)}</p>

          {product.description && (
            <p className="text-smoke text-[15px] leading-relaxed mb-8 max-w-md">{product.description}</p>
          )}

          {/* Finish selector */}
          <div className="mb-8">
            <h4 className="eyebrow mb-3">Finish</h4>
            <div className="flex flex-wrap gap-2.5">
              {FINISH_OPTIONS.map((f) => (
                <button
                  key={f}
                  onClick={() => setFinish(f)}
                  className={`px-4 py-2 text-[12px] tracking-wide border transition-colors duration-300 ${
                    finish === f
                      ? 'border-gold text-gold'
                      : 'border-line text-smoke hover:border-smoke hover:text-bone'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Quantity */}
          <div className="mb-9">
            <h4 className="eyebrow mb-3">Quantity</h4>
            <div className="inline-flex items-center border border-line">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-10 h-10 flex items-center justify-center text-smoke hover:text-gold transition-colors"
                aria-label="Decrease quantity"
              >
                <Minus size={14} strokeWidth={1.5} />
              </button>
              <span className="w-10 text-center text-bone text-sm">{quantity}</span>
              <button
                onClick={() => setQuantity((q) => q + 1)}
                className="w-10 h-10 flex items-center justify-center text-smoke hover:text-gold transition-colors"
                aria-label="Increase quantity"
              >
                <Plus size={14} strokeWidth={1.5} />
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleAddToCart}
              className="flex-1 px-8 py-3.5 border border-gold text-gold text-[13px] tracking-widest2 uppercase hover:bg-gold hover:text-ink transition-all duration-400 ease-luxe"
            >
              {added ? 'Added ✓' : 'Add to Cart'}
            </button>
            <button
              onClick={handleBuyNow}
              className="flex-1 px-8 py-3.5 bg-gold text-ink text-[13px] tracking-widest2 uppercase hover:bg-gold-light transition-all duration-400 ease-luxe"
            >
              Buy Now
            </button>
          </div>

          <div className="mt-10 pt-8 border-t border-line space-y-4">
            <div className="flex items-center gap-3 text-sm text-smoke">
              <Truck size={16} strokeWidth={1.5} className="text-gold shrink-0" />
              White-glove delivery, 2–4 weeks (handcrafted to order)
            </div>
            <div className="flex items-center gap-3 text-sm text-smoke">
              <ShieldCheck size={16} strokeWidth={1.5} className="text-gold shrink-0" />
              Lifetime finish guarantee
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
