import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useProducts } from '../hooks/useProducts'
import ProductCard from '../components/ProductCard'
import { Spinner, EmptyState } from '../components/UI'

const FINISHES = ['Brushed Brass', 'Antique Copper', 'Matte Black', 'Mixed Metal']

export default function Shop() {
  const { products, loading } = useProducts()
  const [searchParams, setSearchParams] = useSearchParams()
  const activeCategory = searchParams.get('category') || 'All'
  const [activeFinish, setActiveFinish] = useState('All')

  const categories = useMemo(() => {
    const set = new Set(products.map((p) => p.category).filter(Boolean))
    return ['All', ...Array.from(set)]
  }, [products])

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchCategory = activeCategory === 'All' || p.category === activeCategory
      const matchFinish = activeFinish === 'All' || p.finish === activeFinish
      return matchCategory && matchFinish
    })
  }, [products, activeCategory, activeFinish])

  function setCategory(cat) {
    if (cat === 'All') {
      searchParams.delete('category')
    } else {
      searchParams.set('category', cat)
    }
    setSearchParams(searchParams)
  }

  return (
    <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-14">
      <div className="mb-10">
        <p className="eyebrow mb-3">The Collection</p>
        <h1 className="font-display font-light text-4xl md:text-5xl text-bone">Shop All</h1>
      </div>

      <div className="grid lg:grid-cols-[220px_1fr] gap-10">
        {/* Filters */}
        <aside className="space-y-9">
          <div>
            <h4 className="eyebrow mb-4">Category</h4>
            <ul className="space-y-2.5">
              {categories.map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => setCategory(cat)}
                    className={`text-[13px] tracking-wide transition-colors ${
                      activeCategory === cat ? 'text-gold' : 'text-smoke hover:text-bone'
                    }`}
                  >
                    {cat}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="eyebrow mb-4">Finish</h4>
            <ul className="space-y-2.5">
              {['All', ...FINISHES].map((f) => (
                <li key={f}>
                  <button
                    onClick={() => setActiveFinish(f)}
                    className="flex items-center gap-2.5 text-[13px] tracking-wide text-smoke hover:text-bone transition-colors"
                  >
                    <span
                      className={`w-3.5 h-3.5 rounded-full border ${
                        activeFinish === f ? 'border-gold' : 'border-line'
                      } flex items-center justify-center`}
                    >
                      {activeFinish === f && <span className="w-1.5 h-1.5 rounded-full bg-gold" />}
                    </span>
                    <span className={activeFinish === f ? 'text-gold' : ''}>{f}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        {/* Grid */}
        <div>
          {loading ? (
            <Spinner label="Loading products" />
          ) : filtered.length === 0 ? (
            <EmptyState
              title="Nothing here yet"
              subtitle="Try a different category or finish, or check back soon as new pieces are added."
            />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-12">
              {filtered.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
