import { Link } from 'react-router-dom'
import { Minus, Plus, X, ArrowRight, ShoppingBag } from 'lucide-react'
import { useCart } from '../context/CartContext'
import { formatINR } from '../utils/format'
import { EmptyState } from '../components/UI'

export default function Cart() {
  const { items, updateQuantity, removeItem, subtotal } = useCart()

  if (items.length === 0) {
    return (
      <div className="max-w-[1400px] mx-auto px-5 md:px-10">
        <EmptyState
          title="Your cart is empty"
          subtitle="Browse the collection and add pieces that speak to you."
          action={
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 px-7 py-3 border border-gold text-gold text-[13px] tracking-widest2 uppercase hover:bg-gold hover:text-ink transition-all duration-400 ease-luxe"
            >
              <ShoppingBag size={15} strokeWidth={1.5} /> Shop the Collection
            </Link>
          }
        />
      </div>
    )
  }

  return (
    <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-14">
      <h1 className="font-display font-light text-4xl text-bone mb-10">Your Cart</h1>

      <div className="grid lg:grid-cols-[1fr_360px] gap-12">
        <div className="divide-y divide-line border-y border-line">
          {items.map((item) => (
            <div key={item.lineId} className="flex gap-5 py-6">
              <div className="w-24 h-28 bg-ink2 shrink-0 overflow-hidden">
                {item.image && (
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                )}
              </div>
              <div className="flex-1 flex flex-col justify-between">
                <div className="flex justify-between gap-4">
                  <div>
                    <h3 className="text-[14px] tracking-wide uppercase text-bone">{item.title}</h3>
                    {item.finish && (
                      <p className="text-xs text-smoke mt-1">Finish: {item.finish}</p>
                    )}
                  </div>
                  <button
                    onClick={() => removeItem(item.lineId)}
                    className="text-smoke hover:text-gold transition-colors h-fit"
                    aria-label={`Remove ${item.title}`}
                  >
                    <X size={16} strokeWidth={1.5} />
                  </button>
                </div>
                <div className="flex items-center justify-between mt-3">
                  <div className="inline-flex items-center border border-line">
                    <button
                      onClick={() => updateQuantity(item.lineId, item.quantity - 1)}
                      className="w-8 h-8 flex items-center justify-center text-smoke hover:text-gold transition-colors"
                      aria-label="Decrease quantity"
                    >
                      <Minus size={12} strokeWidth={1.5} />
                    </button>
                    <span className="w-8 text-center text-bone text-xs">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.lineId, item.quantity + 1)}
                      className="w-8 h-8 flex items-center justify-center text-smoke hover:text-gold transition-colors"
                      aria-label="Increase quantity"
                    >
                      <Plus size={12} strokeWidth={1.5} />
                    </button>
                  </div>
                  <span className="text-gold text-sm">{formatINR(item.price * item.quantity)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="h-fit bg-ink2 border border-line p-7">
          <h4 className="eyebrow mb-5">Order Summary</h4>
          <div className="flex justify-between text-sm text-smoke mb-3">
            <span>Subtotal</span>
            <span>{formatINR(subtotal)}</span>
          </div>
          <div className="flex justify-between text-sm text-smoke mb-5">
            <span>Delivery</span>
            <span className="text-gold">Calculated at checkout</span>
          </div>
          <div className="flex justify-between text-base text-bone border-t border-line pt-5 mb-7">
            <span>Total</span>
            <span className="text-gold">{formatINR(subtotal)}</span>
          </div>
          <Link
            to="/checkout"
            className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-gold text-ink text-[13px] tracking-widest2 uppercase hover:bg-gold-light transition-all duration-400 ease-luxe"
          >
            Proceed to Checkout <ArrowRight size={15} strokeWidth={1.5} />
          </Link>
        </div>
      </div>
    </div>
  )
}
