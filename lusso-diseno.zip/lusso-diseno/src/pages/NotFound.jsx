import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-32 text-center">
      <h1 className="font-display font-light text-6xl text-gold mb-4">404</h1>
      <p className="text-smoke mb-8">This page doesn't exist.</p>
      <Link to="/" className="text-gold text-sm tracking-widest2 uppercase">Return Home</Link>
    </div>
  )
}
