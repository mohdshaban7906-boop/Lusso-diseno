export default function Journal() {
  return (
    <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-24 text-center">
      <p className="eyebrow mb-4">The Journal</p>
      <h1 className="font-display font-light text-4xl text-bone mb-4">Stories in the Making</h1>
      <p className="text-smoke max-w-md mx-auto">
        Notes on craft, material and interiors — coming soon.
      </p>
    </div>
  )
}
