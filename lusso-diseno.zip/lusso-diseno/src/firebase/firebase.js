// src/firebase/firebase.js
//
// Firebase initialization for Lusso Diseño.
// Exports `db` (Firestore) and `auth` (Auth) for use across the app.

import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'
import { getAuth } from 'firebase/auth'

const firebaseConfig = {
  apiKey: 'AIzaSyCTabchSFv-Z7QP8ao06xD2gxbj46Rih0w',
  authDomain: 'lusso-diseno.firebaseapp.com',
  projectId: 'lusso-diseno',
  storageBucket: 'lusso-diseno.firebasestorage.app',
  messagingSenderId: '329332529626',
  appId: '1:329332529626:web:59caa6059e74c5710dc8e3',
  measurementId: 'G-P1JRFWZ1Z0',
}

const app = initializeApp(firebaseConfig)

export const db = getFirestore(app)
export const auth = getAuth(app)
export default app

/**
 * ─────────────────────────────────────────────────────────────────────────
 * FIRESTORE SECURITY RULES — read this before going live
 * ─────────────────────────────────────────────────────────────────────────
 * By default a brand-new Firestore database denies all reads/writes. To get
 * this storefront working, go to:
 *
 *   Firebase Console → your project (lusso-diseno) → Firestore Database
 *   → Rules tab → paste the rules below → Publish
 *
 * DEVELOPMENT / QUICK START (open read, public write to orders only):
 * ---------------------------------------------------------------------------
 * rules_version = '2';
 * service cloud.firestore {
 *   match /databases/{database}/documents {
 *
 *     // Anyone can browse the catalog
 *     match /products/{productId} {
 *       allow read: if true;
 *       allow write: if request.auth != null; // only signed-in admins write
 *     }
 *
 *     // Anyone can place an order (create), but not read/edit others' orders
 *     match /orders/{orderId} {
 *       allow create: if true;
 *       allow read, update, delete: if request.auth != null; // admin only
 *     }
 *   }
 * }
 * ---------------------------------------------------------------------------
 *
 * PRODUCTION RECOMMENDATION:
 * Lock product writes and order reads behind Firebase Authentication.
 * The admin panel in this app signs in with Firebase Auth (email/password)
 * before writing to `products` or reading `orders`, so the rules above
 * pair directly with that flow. Create your admin user in:
 *   Firebase Console → Authentication → Users → Add user
 * ─────────────────────────────────────────────────────────────────────────
 */
