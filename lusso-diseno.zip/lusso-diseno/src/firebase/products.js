// src/firebase/products.js
// CRUD helpers for the `products` collection.

import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  getDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore'
import { db } from './firebase'

const productsRef = collection(db, 'products')

// One-time fetch of all products, newest first.
export async function fetchProducts() {
  const q = query(productsRef, orderBy('createdAt', 'desc'))
  const snap = await getDocs(q)
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }))
}

// Real-time subscription — used by the shop page and admin CMS so
// changes made in the admin panel appear instantly for shoppers.
export function subscribeToProducts(callback, onError) {
  const q = query(productsRef, orderBy('createdAt', 'desc'))
  return onSnapshot(
    q,
    (snap) => callback(snap.docs.map((d) => ({ id: d.id, ...d.data() }))),
    onError
  )
}

export async function fetchProductById(id) {
  const ref = doc(db, 'products', id)
  const snap = await getDoc(ref)
  if (!snap.exists()) return null
  return { id: snap.id, ...snap.data() }
}

// product: { title, price, description, category, image, finish?, room? }
export async function createProduct(product) {
  return addDoc(productsRef, {
    ...product,
    createdAt: serverTimestamp(),
  })
}

export async function updateProduct(id, updates) {
  const ref = doc(db, 'products', id)
  return updateDoc(ref, updates)
}

export async function deleteProduct(id) {
  const ref = doc(db, 'products', id)
  return deleteDoc(ref)
}
