// src/firebase/orders.js
// CRUD helpers for the `orders` collection.

import {
  collection,
  addDoc,
  getDocs,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore'
import { db } from './firebase'

const ordersRef = collection(db, 'orders')

// order: { name, address, phone, email, items: [...], total, status }
export async function createOrder(order) {
  return addDoc(ordersRef, {
    ...order,
    status: 'pending',
    createdAt: serverTimestamp(),
  })
}

export async function fetchOrders() {
  const q = query(ordersRef, orderBy('createdAt', 'desc'))
  const snap = await getDocs(q)
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }))
}

// Real-time subscription — powers the admin dashboard's live order count
// and order list without needing a manual refresh.
export function subscribeToOrders(callback, onError) {
  const q = query(ordersRef, orderBy('createdAt', 'desc'))
  return onSnapshot(
    q,
    (snap) => callback(snap.docs.map((d) => ({ id: d.id, ...d.data() }))),
    onError
  )
}
