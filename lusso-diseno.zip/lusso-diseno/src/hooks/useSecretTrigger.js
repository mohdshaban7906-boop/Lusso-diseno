import { useRef, useCallback } from 'react'

/**
 * Fires `onTrigger` after `requiredClicks` clicks land within
 * `windowMs` of each other. Attach the returned `onClick` handler
 * to any element (the logo, in this app) — there is no visible
 * affordance, counter, or hint anywhere in the UI.
 */
export function useSecretTrigger(onTrigger, { requiredClicks = 10, windowMs = 1500 } = {}) {
  const clicksRef = useRef([])

  const onClick = useCallback(() => {
    const now = Date.now()
    clicksRef.current = [...clicksRef.current, now].filter((t) => now - t <= windowMs)

    if (clicksRef.current.length >= requiredClicks) {
      clicksRef.current = []
      onTrigger()
    }
  }, [onTrigger, requiredClicks, windowMs])

  return onClick
}
