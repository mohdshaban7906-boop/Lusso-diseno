import { Routes, Route, useLocation } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import Shop from './pages/Shop'
import ProductDetail from './pages/ProductDetail'
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import Journal from './pages/Journal'
import NotFound from './pages/NotFound'
import AdminPanel from './admin/AdminPanel'

export default function App() {
  const location = useLocation()
  // The admin route renders its own full-screen shell — no public
  // header/footer, no visible link to it anywhere in the site.
  const isAdmin = location.pathname.startsWith('/control-9f2x')

  if (isAdmin) {
    return (
      <Routes>
        <Route path="/control-9f2x" element={<AdminPanel />} />
      </Routes>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-ink">
      <Header />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/journal" element={<Journal />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}
