import { Instagram, Facebook, Mail, Phone, MapPin } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="border-t border-line bg-ink2 mt-24">
      <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-16 grid grid-cols-2 md:grid-cols-4 gap-10">
        <div className="col-span-2 md:col-span-1">
          <div className="font-display text-2xl tracking-[0.08em] text-bone">LUSSO</div>
          <div className="text-[10px] tracking-widest2 text-gold mt-1">DISEÑO</div>
          <p className="text-sm text-smoke mt-5 leading-relaxed max-w-xs">
            Handcrafted brass, copper and stone pieces for interiors built to be lived in slowly.
          </p>
          <div className="flex gap-4 mt-6">
            <a href="#" aria-label="Instagram" className="text-smoke hover:text-gold transition-colors">
              <Instagram size={17} strokeWidth={1.5} />
            </a>
            <a href="#" aria-label="Facebook" className="text-smoke hover:text-gold transition-colors">
              <Facebook size={17} strokeWidth={1.5} />
            </a>
          </div>
        </div>

        <div>
          <h4 className="eyebrow mb-5">Contact</h4>
          <ul className="space-y-3 text-sm text-smoke">
            <li className="flex items-center gap-2">
              <Phone size={14} strokeWidth={1.5} className="text-gold shrink-0" />
              +91 070 682 390
            </li>
            <li className="flex items-center gap-2">
              <Mail size={14} strokeWidth={1.5} className="text-gold shrink-0" />
              atelier@lussodiseno.com
            </li>
            <li className="flex items-center gap-2">
              <MapPin size={14} strokeWidth={1.5} className="text-gold shrink-0" />
              www.lussodiseno.com
            </li>
          </ul>
        </div>

        <div>
          <h4 className="eyebrow mb-5">Navigate</h4>
          <ul className="space-y-3 text-sm text-smoke">
            <li><a href="/" className="hover:text-gold transition-colors">Home</a></li>
            <li><a href="/shop" className="hover:text-gold transition-colors">Shop</a></li>
            <li><a href="/shop?category=Furniture" className="hover:text-gold transition-colors">Furniture</a></li>
            <li><a href="/cart" className="hover:text-gold transition-colors">Cart</a></li>
          </ul>
        </div>

        <div>
          <h4 className="eyebrow mb-5">Payment</h4>
          <p className="text-sm text-smoke leading-relaxed">
            We accept Visa, Mastercard, American Express and UPI. All orders are confirmed by our atelier within 24 hours.
          </p>
        </div>
      </div>

      <div className="border-t border-line">
        <div className="max-w-[1400px] mx-auto px-5 md:px-10 py-6 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-smoke/70">
          <span>© {new Date().getFullYear()} Lusso Diseño. All rights reserved.</span>
          <span>Privacy Policy</span>
        </div>
      </div>
    </footer>
  )
}
