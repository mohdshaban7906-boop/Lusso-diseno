export function SectionHeading({ eyebrow, title, align = 'left' }) {
  return (
    <div className={align === 'center' ? 'text-center' : ''}>
      {eyebrow && <p className="eyebrow mb-3">{eyebrow}</p>}
      <h2 className="font-display text-3xl md:text-4xl text-bone font-light">{title}</h2>
    </div>
  )
}

export function Spinner({ label = 'Loading' }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 gap-4 text-smoke">
      <div className="w-8 h-8 border border-line border-t-gold rounded-full animate-spin" />
      <span className="text-xs tracking-widest2 uppercase">{label}</span>
    </div>
  )
}

export function EmptyState({ title, subtitle, action }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-24 px-6">
      <h3 className="font-display text-2xl text-bone mb-2">{title}</h3>
      {subtitle && <p className="text-smoke text-sm max-w-sm mb-6">{subtitle}</p>}
      {action}
    </div>
  )
}
