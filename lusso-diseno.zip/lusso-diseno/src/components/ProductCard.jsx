import { Link } from 'react-router-dom'
import { Plus } from 'lucide-react'
import { formatINR } from '../utils/format'
import { useCart } from '../context/CartContext'

export default function ProductCard({ product }) {
  const { addItem } = useCart()

  return (
    <div className="group">
      <Link to={`/product/${product.id}`} className="block relative overflow-hidden bg-ink2 aspect-[4/5]">
        {product.image ? (
          <img
            src={product.image}
            alt={product.title}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-700 ease-luxe group-hover:scale-[1.06]"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-smoke text-xs tracking-wide">
            No image
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        <button
          onClick={(e) => {
            e.preventDefault()
            addItem(product)
          }}
          className="absolute bottom-3 right-3 w-9 h-9 rounded-full bg-ink/80 border border-gold/40 flex items-center justify-center text-gold opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-400 ease-luxe hover:bg-gold hover:text-ink"
          aria-label={`Add ${product.title} to cart`}
        >
          <Plus size={16} strokeWidth={1.75} />
        </button>
      </Link>
      <Link to={`/product/${product.id}`} className="block mt-4">
        <h3 className="text-[13px] tracking-wide uppercase text-bone group-hover:text-gold transition-colors duration-300">
          {product.title}
        </h3>
        <p className="text-sm text-gold mt-1 font-body">{formatINR(product.price)}</p>
      </Link>
    </div>
  )
}
