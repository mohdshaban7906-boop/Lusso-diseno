import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Search, ShoppingBag, Menu, X } from 'lucide-react'
import { useCart } from '../context/CartContext'
import { useSecretTrigger } from '../hooks/useSecretTrigger'

const NAV_LINKS = [
  { label: 'Home', to: '/' },
  { label: 'Shop', to: '/shop' },
  { label: 'Art', to: '/shop?category=Art' },
  { label: 'Furniture', to: '/shop?category=Furniture' },
  { label: 'Journal', to: '/journal' },
]

export default function Header() {
  const { count } = useCart()
  const [mobileOpen, setMobileOpen] = useState(false)
  const navigate = useNavigate()

  // Completely hidden: 10 rapid clicks on the wordmark opens the admin
  // panel. No visible button, no counter, no hint anywhere in the DOM.
  const onLogoClick = useSecretTrigger(() => navigate('/control-9f2x'), {
    requiredClicks: 10,
    windowMs: 1500,
  })

  return (
    <header className="sticky top-0 z-40 bg-ink/95 backdrop-blur border-b border-line">
      <div className="max-w-[1400px] mx-auto px-5 md:px-10 h-[76px] flex items-center justify-between">
        <button
          onClick={onLogoClick}
          className="select-none text-left"
          aria-label="Lusso Diseño"
        >
          <span className="font-display text-2xl md:text-[28px] tracking-[0.08em] text-bone">
            LUSSO
          </span>
          <span className="block -mt-1 text-[10px] tracking-widest2 text-gold font-body">
            DISEÑO
          </span>
        </button>

        <nav className="hidden lg:flex items-center gap-10">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.label}
              to={link.to}
              className={({ isActive }) =>
                `text-[13px] tracking-wide uppercase font-body transition-colors duration-300 ${
                  isActive ? 'text-gold' : 'text-smoke hover:text-bone'
                }`
              }
              end={link.to === '/'}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-5">
          <button
            className="hidden sm:block text-smoke hover:text-gold transition-colors duration-300"
            aria-label="Search"
          >
            <Search size={19} strokeWidth={1.5} />
          </button>
          <Link
            to="/cart"
            className="relative text-smoke hover:text-gold transition-colors duration-300"
            aria-label={`Cart, ${count} items`}
          >
            <ShoppingBag size={19} strokeWidth={1.5} />
            {count > 0 && (
              <span className="absolute -top-2 -right-2 w-4 h-4 rounded-full bg-gold text-ink text-[10px] font-medium flex items-center justify-center">
                {count > 9 ? '9+' : count}
              </span>
            )}
          </Link>
          <button
            className="lg:hidden text-smoke hover:text-gold"
            onClick={() => setMobileOpen((v) => !v)}
            aria-label="Menu"
          >
            {mobileOpen ? <X size={20} strokeWidth={1.5} /> : <Menu size={20} strokeWidth={1.5} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="lg:hidden border-t border-line bg-ink px-5 py-6 flex flex-col gap-5">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.label}
              to={link.to}
              onClick={() => setMobileOpen(false)}
              className="text-[13px] tracking-wide uppercase text-smoke hover:text-gold"
            >
              {link.label}
            </NavLink>
          ))}
        </div>
      )}
    </header>
  )
}
